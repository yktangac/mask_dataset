Data structure and what they are for:
Annotations folder: optional, if you have XML format label to convert it to Yolo Format.
Images:
three sets: training set, validation set, and testing set
Labels:
three sets: training set, validation set, and testing set
----------------------------------------------------------------------------------------
creaet a data.yaml file:
path: # dataset root_dir
train: # training images relative to 'path'
validation: # validation images relative to 'path'
test: # test images (optional) just for evaluation.


#Classes
nc: #number of classes you want to detect in my case, 2 for no-mask and mask
names: [ 'mask', 'no mask']
----------------------------------------------------------------------------------------

data label format(*.txt):
format ---> class x_center y_center width height
One row per object instance
Each row is using the above format
Box coordinates must be normalized xywh format(from 0-1).
If your boxes are in pixels, divide x_center and width by images, and y_center and height by image height.
---> normalized x_center_nm = x_center/image_width
---> normalized width = width/image_width
---> normalized y_center  = y_center/image_height
---> normalized height = height/image_height
classes number are zero-indexed (starting from 0).
Example:
c x_center           y_center width               height
0 0.6345833333333334 0.475625 0.06916666666666667 0.11625
0 0.36333333333333334 0.40125 0.07333333333333333 0.1225
0 0.47541666666666665 0.30125 0.08083333333333333 0.12

Important issue for training your custom dataset:
img: define input image size
batch : batch size 
epochs : duration of the training (3000+ is commonly set)
cfg: specify model configuration
weights: specifically a custom path to weights 
name: result name
nosave: only save the final checkpoint
cache: cache images for faster learning




